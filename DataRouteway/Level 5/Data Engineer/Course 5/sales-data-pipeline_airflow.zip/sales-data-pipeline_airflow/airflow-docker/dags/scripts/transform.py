import pandas as pd
import os
import glob


def transform_data():
    """
    Transform step of the pipeline

    What this script does:
      1) Reads source data directly from SharePoint
      2) Cleans and standardises fields (Silver)
      3) Aggregates and joins data (Gold)
      4) Saves outputs
    """

    print("Transforming data...")

    # -----------------------------------------------------------
    # Step 0: Read data from SharePoint directly
    # -----------------------------------------------------------
    SHAREPOINT_PATH = "/opt/airflow/dags/data/sharepoint"

    sales_files = glob.glob(os.path.join(SHAREPOINT_PATH, "RetailSales_*.csv"))
    order_files = glob.glob(os.path.join(SHAREPOINT_PATH, "OrderBank_*.csv"))

    if not sales_files or not order_files:
        raise FileNotFoundError("Source files missing in SharePoint folder")

    retail_df = pd.read_csv(sales_files[0])
    order_df = pd.read_csv(order_files[0])

    print("Loaded retail file:", sales_files[0])
    print("Loaded order file:", order_files[0])

    # -----------------------------------------------------------
    # Step 1: Setup output folders
    # -----------------------------------------------------------
    BASE_PATH = "/tmp/data/processed"
    SILVER_PATH = os.path.join(BASE_PATH, "silver")
    GOLD_PATH = os.path.join(BASE_PATH, "gold")

    os.makedirs(SILVER_PATH, exist_ok=True)
    os.makedirs(GOLD_PATH, exist_ok=True)

    # -----------------------------------------------------------
    # Step 2: Copy data
    # -----------------------------------------------------------
    retail = retail_df.copy()
    orders = order_df.copy()

    # -----------------------------------------------------------
    # Step 3: Cleaning & standardisation (Silver layer)
    # -----------------------------------------------------------
    retail["country"] = retail["country"].astype(str).str.strip()
    retail["dealer_id"] = retail["dealer_id"].astype(str).str.strip()
    retail["model"] = retail["model"].astype(str).str.strip()
    retail["powertrain"] = retail["powertrain"].astype(str).str.strip()

    orders["country"] = orders["country"].astype(str).str.strip()
    orders["dealer_id"] = orders["dealer_id"].astype(str).str.strip()
    orders["model"] = orders["model"].astype(str).str.strip()
    orders["powertrain"] = orders["powertrain"].astype(str).str.strip()

    # Convert dates
    retail["report_month"] = pd.to_datetime(retail["report_month"]).dt.to_period("M").astype(str)
    orders["order_month"] = pd.to_datetime(orders["order_date"]).dt.to_period("M").astype(str)

    # -----------------------------------------------------------
    # Step 4: Save Silver layer
    # -----------------------------------------------------------
    retail.to_csv(os.path.join(SILVER_PATH, "retail_clean.csv"), index=False)
    orders.to_csv(os.path.join(SILVER_PATH, "orders_clean.csv"), index=False)

    print("Saved cleaned data to SILVER layer")

    # -----------------------------------------------------------
    # Step 5: Aggregate orders
    # -----------------------------------------------------------
    orders_agg = orders.groupby(
        ["country", "dealer_id", "model", "powertrain", "order_month"]
    ).size().reset_index(name="orders")

    # -----------------------------------------------------------
    # Step 6: Join datasets
    # -----------------------------------------------------------
    final_df = retail.merge(
        orders_agg,
        left_on=["country", "dealer_id", "model", "powertrain", "report_month"],
        right_on=["country", "dealer_id", "model", "powertrain", "order_month"],
        how="left"
    )

    final_df["orders"] = final_df["orders"].fillna(0)

    # -----------------------------------------------------------
    # Step 7: Save Gold layer
    # -----------------------------------------------------------
    final_df.to_csv(os.path.join(GOLD_PATH, "final_dataset.csv"), index=False)

    print("Saved final dataset to GOLD layer")