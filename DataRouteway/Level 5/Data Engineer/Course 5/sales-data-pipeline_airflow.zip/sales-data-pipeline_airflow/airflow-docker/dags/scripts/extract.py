import pandas as pd
import glob
import os


def extract_data():
    """
    Extract step of the pipeline

    What this function does:
    1. Checks if source files exist in SharePoint folder
    2. Loads the data into pandas DataFrames
    3. Logs useful information
    """

    print("Extracting data from source sharepoint folder...")

    # Base path
    BASE_PATH = "/opt/airflow/dags/data"
    SHAREPOINT_PATH = os.path.join(BASE_PATH, "sharepoint")

    # -----------------------------------------------------------
    # Step 1: Locate files
    # -----------------------------------------------------------
    sales_files = glob.glob(os.path.join(SHAREPOINT_PATH, "RetailSales_*.csv"))
    order_files = glob.glob(os.path.join(SHAREPOINT_PATH, "OrderBank_*.csv"))

    if not sales_files or not order_files:
        raise FileNotFoundError("Source files missing in data/sharepoint/")

    sales_path = sales_files[0]
    order_path = order_files[0]

    print("Found sales file:", sales_path)
    print("Found order file:", order_path)

    # -----------------------------------------------------------
    # Step 2: Load data (for validation/logging)
    # -----------------------------------------------------------
    retail_df = pd.read_csv(sales_path)
    order_df = pd.read_csv(order_path)

    print("Retail dataset shape:", retail_df.shape)
    print("Order dataset shape:", order_df.shape)

    # -----------------------------------------------------------
    # Step 3: Return (not used by next task directly in Airflow)
    # -----------------------------------------------------------
    return retail_df, order_df