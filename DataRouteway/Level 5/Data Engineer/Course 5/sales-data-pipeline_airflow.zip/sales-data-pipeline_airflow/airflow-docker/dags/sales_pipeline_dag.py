from airflow import DAG
from airflow.operators.python import PythonOperator
from datetime import datetime

# Import functions directly
from scripts.extract import extract_data
from scripts.transform import transform_data

with DAG(
    dag_id="sales_data_pipeline",
    start_date=datetime(2024, 1, 1),
    schedule_interval="@daily",
    catchup=False
) as dag:

    extract_task = PythonOperator(
        task_id="extract_task",
        python_callable=extract_data
    )

    transform_task = PythonOperator(
        task_id="transform_task",
        python_callable=transform_data
    )

    # Define workflow order
    extract_task >> transform_task